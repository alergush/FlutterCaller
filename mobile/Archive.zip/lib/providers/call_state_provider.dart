import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_caller/models/caller.dart';
import 'package:flutter_caller/models/methods.dart';
import 'package:flutter_caller/models/call_state.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_caller/models/call_status.dart';

final _methodChannel = MethodChannel(
  'com.alergush.flutter_caller/call_methods',
);

final eventChannel = EventChannel('com.alergush.flutter_caller/call_events');

class CallNotifier extends Notifier<CallState> {
  @override
  CallState build() {
    return CallState();
  }

  void syncWithMap(Map<dynamic, dynamic> data) {
    final String statusStr = data['callStatus'] ?? "idle";

    final status = CallStatus.values.firstWhere(
      (e) => e.name == statusStr.toLowerCase(),
      orElse: () => CallStatus.idle,
    );

    if (state.callStatus == CallStatus.disconnected &&
        status == CallStatus.connected) {
      debugPrint("Ignoring stale CONNECTED event after hangup.");
      return;
    }

    final int startTimeMs = data['callStartTime'] ?? 0;

    final bool isEnding =
        status == CallStatus.idle || status == CallStatus.disconnected;

    state = state.copyWith(
      callStatus: status,
      // caller: Caller(
      //   name: data['callerName'] ?? "Unknown",
      //   phone: data['callerPhone'] ?? "Unknown",
      // ),
      caller: isEnding
          ? state.caller
          : Caller(
              name: data['callerName'] ?? "Unknown",
              phone: data['callerPhone'] ?? "Unknown",
            ),
      connectedAt: startTimeMs > 0
          ? DateTime.fromMillisecondsSinceEpoch(startTimeMs)
          : null,
      callScreenState: state.callScreenState.copyWith(
        isMicrophoneButtonPressed: data['isMuted'] ?? false,
        isSpeakerButtonPressed: data['isSpeakerOn'] ?? false,
      ),
    );
  }

  void minimize() {
    state = state.copyWith(
      callScreenState: state.callScreenState.copyWith(isMinimized: true),
    );
  }

  void maximize() {
    state = state.copyWith(
      callScreenState: state.callScreenState.copyWith(isMinimized: false),
    );
  }

  // --- ACTIONS (Doar trimit comenzi la Java) ---

  Future<void> answer() async {
    try {
      await _methodChannel.invokeMethod(Methods.answer);
    } catch (e) {
      debugPrint("Error: $e");
    }
  }

  Future<void> hangup() async {
    try {
      await _methodChannel.invokeMethod(Methods.hangup);
    } catch (e) {
      debugPrint("Error: $e");
    }
  }

  Future<void> toggleMicrophone() async {
    try {
      await _methodChannel.invokeMethod(Methods.toggleMute, {
        Methods.toggleMuteParamIsMute:
            !state.callScreenState.isMicrophoneButtonPressed,
      });
    } catch (e) {
      debugPrint("Error: $e");
    }
  }

  Future<void> toggleSpeaker() async {
    try {
      await _methodChannel.invokeMethod(Methods.toggleSpeaker, {
        Methods.toggleSpeakerParamIsSpeaker:
            !state.callScreenState.isSpeakerButtonPressed,
      });
    } catch (e) {
      debugPrint("Error: $e");
    }
  }
}

final callStateProvider = NotifierProvider<CallNotifier, CallState>(
  CallNotifier.new,
);
