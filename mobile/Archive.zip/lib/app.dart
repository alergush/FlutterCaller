import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:permission_handler/permission_handler.dart';

import 'package:flutter_caller/models/methods.dart';
import 'package:flutter_caller/models/call_status.dart';
import 'package:flutter_caller/screens/home_screen.dart';
import 'package:flutter_caller/screens/call_screen.dart';
import 'package:flutter_caller/widgets/call_overlay_manager.dart';
import 'package:flutter_caller/providers/call_state_provider.dart';

// --- CONSTANTS ---
const serverBaseUrl = "http://192.168.0.150:3000/api";

// --- GLOBALS ---
final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

// Canalele trebuie să aibă aceleași nume ca în MainActivity.java
const MethodChannel methodChannel = MethodChannel(
  'com.alergush.flutter_caller/call_methods',
);
const EventChannel eventChannel = EventChannel(
  'com.alergush.flutter_caller/call_events',
);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ProviderScope(child: App()));
}

class App extends ConsumerStatefulWidget {
  const App({super.key});

  @override
  ConsumerState<App> createState() => _AppState();
}

class _AppState extends ConsumerState<App> with WidgetsBindingObserver {
  String? _accessToken;
  StreamSubscription? _eventSubscription;

  bool _isCallScreenOpened = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    _setup();
    _initEventListener();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _eventSubscription?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // if (state == AppLifecycleState.resumed) {
    //   // ACTIVARE: Verificăm starea imediat ce aplicația revine în prim-plan
    //   _checkActiveCallState();
    // }
  }

  Future<void> _setup() async {
    bool permissionsGranted = await _checkPermissions();
    if (permissionsGranted) {
      await _register();
    } else {
      await methodChannel.invokeMethod('checkPermissions');
      // debugPrint("Permissions denied. App functionality limited.");
    }
  }

  Future<bool> _checkPermissions() async {
    var micStatus = await Permission.microphone.status;
    var notifStatus = await Permission.notification.status;

    if (!micStatus.isGranted || !notifStatus.isGranted) {
      Map<Permission, PermissionStatus> statuses = await [
        Permission.microphone,
        Permission.notification,
        Permission.phone,
        if (Platform.isAndroid) Permission.bluetoothConnect,
      ].request();

      return statuses[Permission.microphone] == PermissionStatus.granted &&
          statuses[Permission.notification] == PermissionStatus.granted;
    }
    return true;
  }

  Future<void> _register() async {
    try {
      String? fcmToken = await FirebaseMessaging.instance.getToken();
      debugPrint("FCM Token: $fcmToken");

      final url = Uri.parse('$serverBaseUrl/voice/token');
      final response = await http.get(url);

      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);
        _accessToken = data['token'];
        debugPrint("Twilio Access Token received");

        if (fcmToken != null && _accessToken != null) {
          await methodChannel.invokeMethod(Methods.register, {
            'accessToken': _accessToken,
            'fcmToken': fcmToken,
          });
        }
      } else {
        debugPrint('Server Error: ${response.statusCode}');
      }
    } catch (e) {
      debugPrint('Registration Error: $e');
    }
  }

  void _initEventListener() {
    _eventSubscription = eventChannel.receiveBroadcastStream().listen(
      _onEventReceived,
      onError: (dynamic error) {
        debugPrint('Event Stream Error: $error');
      },
    );
  }

  Future<void> _checkActiveCallState() async {
    try {
      // Cerem starea actuală din CallStateManager (Java)
      final result = await methodChannel.invokeMethod(
        Methods.checkCallState,
      );
      if (result != null && result is Map) {
        ref.read(callStateProvider.notifier).syncWithMap(result);

        final status = ref.read(callStateProvider).callStatus;
        if (status != CallStatus.idle && status != CallStatus.disconnected) {
          _openCallScreen();
        }
      }
    } catch (e) {
      debugPrint("Sync Error: $e");
    }
  }

  // --- 4. NAVIGATION LOGIC (Fixing the Stacking Issue) ---

  // În lib/app.dart

  Future<void> _onEventReceived(dynamic event) async {
    if (event is Map) {
      debugPrint("Event received from Java: $event");
      ref.read(callStateProvider.notifier).syncWithMap(event);

      final status = ref.read(callStateProvider).callStatus;

      // LOGICĂ DE NAVIGARE CENTRALIZATĂ
      if (status != CallStatus.idle && status != CallStatus.disconnected) {
        _openCallScreen();
      } else {
        // DACĂ APELUL S-A TERMINAT: Închidem ecranele de apel și revenim la Home
        _closeCallScreen();
      }
    }
  }

  void _openCallScreen() {
    if (_isCallScreenOpened) return;

    // Verificăm dacă există DEJA o rută numită '/call_screen' în stivă
    bool alreadyExists = false;
    navigatorKey.currentState?.popUntil((route) {
      if (route.settings.name == '/call_screen') {
        alreadyExists = true;
      }
      return true; // Nu scoatem nimic din stivă, doar verificăm
    });

    if (alreadyExists) {
      _isCallScreenOpened = true; // Sincronizăm flag-ul dacă era greșit
      return;
    }

    _isCallScreenOpened = true;
    navigatorKey.currentState
        ?.push(
          MaterialPageRoute(
            settings: const RouteSettings(name: '/call_screen'),
            builder: (_) => const CallScreen(),
          ),
        )
        .then((_) {
          _isCallScreenOpened = false;
        });
  }

  void _closeCallScreen() {
    // Revenim la ecranul de bază (Home) și eliminăm tot ce e deasupra
    if (_isCallScreenOpened) {
      navigatorKey.currentState?.popUntil((route) => route.isFirst);
      _isCallScreenOpened = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navigatorKey,
      debugShowCheckedModeBanner: false,
      title: 'Flutter Caller',
      home: const Scaffold(
        backgroundColor: Color.fromARGB(255, 38, 38, 38),
        body: CallOverlayManager(child: HomeScreen()),
      ),
    );
  }
}
