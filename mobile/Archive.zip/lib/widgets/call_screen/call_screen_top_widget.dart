import 'package:flutter/material.dart';

import 'package:flutter_caller/models/call_status.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_caller/providers/call_state_provider.dart';

class CallScreenTopWidget extends ConsumerWidget {
  const CallScreenTopWidget({
    super.key,
    this.onPressed,
  });

  final VoidCallback? onPressed;

  final double height = 60;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final callState = ref.watch(callStateProvider);

    final double safeAreaTop = MediaQuery.of(context).padding.top;

    final incomingCallTopWidget = SizedBox(
      height: height,
      child: Stack(
        children: [
          // Minimize Button
          Align(
            alignment: .centerLeft,
            child: Padding(
              padding: EdgeInsets.only(left: 12),
              child: IconButton(
                onPressed: onPressed,
                icon: const Icon(
                  Icons.keyboard_arrow_down,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          // Text
          Align(
            alignment: .center,
            child: Text(
              "Incoming Call",
              style: Theme.of(context).textTheme.bodyLarge!.copyWith(
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );

    // Minimize Button
    final activeCallTopWidget = Align(
      alignment: .topLeft,
      child: Padding(
        padding: EdgeInsets.only(top: safeAreaTop + 6, left: 12),
        child: IconButton(
          onPressed: onPressed,
          icon: const Icon(
            Icons.keyboard_arrow_down,
            color: Colors.white,
          ),
        ),
      ),
    );

    Widget result;

    if (callState.callStatus == CallStatus.ringing) {
      result = incomingCallTopWidget;
    } else if (callState.callStatus == CallStatus.connecting ||
        callState.callStatus == CallStatus.connected) {
      result = activeCallTopWidget;
    } else {
      result = SizedBox(height: height);
    }

    return result;
  }
}
