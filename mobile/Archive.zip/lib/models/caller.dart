class Caller {
  const Caller({
    this.name = "Unknown",
    this.phone = "Unknown",
    this.info,
  });

  final String name;
  final String phone;
  final String? info;
}
