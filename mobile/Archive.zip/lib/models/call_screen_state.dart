class CallScreenState {
  final bool isMinimized;
  final bool isSpeakerButtonPressed;
  final bool isMicrophoneButtonPressed;

  const CallScreenState({
    this.isMinimized = true,
    this.isSpeakerButtonPressed = false,
    this.isMicrophoneButtonPressed = false,
  });

  CallScreenState copyWith({
    bool? isMinimized,
    bool? isSpeakerButtonPressed,
    bool? isMicrophoneButtonPressed,
  }) {
    return CallScreenState(
      isMinimized: isMinimized ?? this.isMinimized,
      isSpeakerButtonPressed:
          isSpeakerButtonPressed ?? this.isSpeakerButtonPressed,
      isMicrophoneButtonPressed:
          isMicrophoneButtonPressed ?? this.isMicrophoneButtonPressed,
    );
  }
}
