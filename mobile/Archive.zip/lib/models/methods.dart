class Methods {
  static const String register = "register";
  static const String answer = "answer";
  static const String hangup = "hangup";
  static const String toggleMute = "toggleMute";
  static const String toggleMuteParamIsMute = "isMuted";
  static const String toggleSpeaker = "toggleSpeaker";
  static const String toggleSpeakerParamIsSpeaker = "isSpeaker";
  static const String checkCallState = "checkCallState";
}
