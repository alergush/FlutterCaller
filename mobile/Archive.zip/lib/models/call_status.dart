enum CallStatus {
  idle,
  ringing,
  connecting,
  connected,
  reconnecting,
  disconnected,
}
