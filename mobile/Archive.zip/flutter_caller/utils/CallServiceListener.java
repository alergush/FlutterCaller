package com.alergush.flutter_caller.utils;

public interface CallServiceListener {
    void onCallStateUpdated();
}
