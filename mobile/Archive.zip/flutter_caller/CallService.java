package com.alergush.flutter_caller;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.ProcessLifecycleOwner;

import com.alergush.flutter_caller.utils.CallServiceListener;
import com.alergush.flutter_caller.utils.CallStateManager;
import com.alergush.flutter_caller.utils.CallEvents;
import com.alergush.flutter_caller.utils.CallStatus;
import com.alergush.flutter_caller.utils.NotificationHelper;
import com.twilio.audioswitch.AudioDevice;
import com.twilio.audioswitch.AudioSwitch;
import com.twilio.voice.Call;
import com.twilio.voice.CallException;
import com.twilio.voice.CallInvite;

public class CallService extends Service {
    private static final String TAG = "CallService";

    private AudioSwitch audioSwitch;
    private CallServiceListener listener;

    private final IBinder binder = new LocalBinder();

    public class LocalBinder extends Binder {
        public CallService getService() {
            return CallService.this;
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    public void setListener(CallServiceListener listener) {
        this.listener = listener;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        audioSwitch = new AudioSwitch(getApplicationContext());

        audioSwitch.start((audioDevices, audioDevice) -> {
            Log.d(TAG, "Audio device changed: " + audioDevice.getName());
            return null;
        });

        NotificationHelper.getInstance(this);
    }

    @Override
    public void onDestroy() {
        if (audioSwitch != null) {
            audioSwitch.stop();
        }
        super.onDestroy();
    }

    private void stopForegroundService() {
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
        audioSwitch.deactivate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || intent.getAction() == null)
            return START_NOT_STICKY;

        CallEvents action;

        try {
            action = CallEvents.valueOf(intent.getAction());
        }
        catch (IllegalArgumentException ex) {
            Log.d(TAG, "onStartCommand() Unrecognized Action: " + intent.getAction());
            return START_NOT_STICKY;
        }

        Log.d(TAG, "onStartCommand() Action received: " + action);

        switch (action) {
            case INCOMING_CALL:
                processIncomingCall();
                break;

            case CANCEL_INCOMING_CALL:
                processCancelIncomingCall();
                break;

            case INCOMING_CALL_DECLINE:
                processIncomingCallDecline();
                break;

            case CALL_CANCEL:
                processCallCancel();
                break;
        }

        return START_NOT_STICKY;
    }

    private boolean isAppInForeground() {
        return ProcessLifecycleOwner.get().getLifecycle()
                .getCurrentState().isAtLeast(Lifecycle.State.STARTED);
    }

    // Events

    public void processIncomingCall() {
        CallInvite activeCallInvite = CallStateManager.getInstance().getActiveCallInvite();

        if (activeCallInvite == null) {

            return;
        }

        if (listener != null) {
            listener.onCallStateUpdated();
        }

        Notification incomingCallNotification;

        if (isAppInForeground()) {
            incomingCallNotification = NotificationHelper.getInstance(this)
                    .createIncomingCallNotification(
                    NotificationHelper.DEF_PRIORITY_CHANNEL_ID,
                    activeCallInvite.getFrom(),
                    NotificationCompat.PRIORITY_DEFAULT
            );
        }
        else {
            incomingCallNotification = NotificationHelper.getInstance(this)
                    .createIncomingCallNotification(
                    NotificationHelper.MAX_PRIORITY_CHANNEL_ID,
                    activeCallInvite.getFrom(),
                    NotificationCompat.PRIORITY_MAX
            );
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                    NotificationHelper.CALL_NOTIFICATION_ID,
                    incomingCallNotification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SHORT_SERVICE
            );
        }
        else {
            startForeground(NotificationHelper.CALL_NOTIFICATION_ID, incomingCallNotification);
        }
    }

    public void processCancelIncomingCall() {
        CallStateManager.getInstance().setActiveCallInvite(null);

        if (listener != null) {
            listener.onCallStateUpdated();
        }

        stopForegroundService();
    }

    public void processIncomingCallDecline() {
        if (listener != null) {
            listener.onCallStateUpdated();
        }

        hangupCall();
        stopForegroundService();
    }

    public void processCallCancel() {
        if (listener != null) {
            listener.onCallStateUpdated();
        }

        hangupCall();
    }

    // Call Methods

    public void answerCall() {
        CallInvite activeCallInvite = CallStateManager.getInstance().getActiveCallInvite();

        if (activeCallInvite == null) return;

        CallStateManager.getInstance().setActiveCallInvite(null);

        try {
            Call activeCall = activeCallInvite.accept(this, callListener);

            CallStateManager.getInstance().setActiveCall(activeCall);

            Notification inCallNotification = NotificationHelper.getInstance(this)
                    .createInCallNotification(
                        NotificationHelper.DEF_PRIORITY_CHANNEL_ID, activeCall.getFrom());

            startForeground(
                    NotificationHelper.CALL_NOTIFICATION_ID,
                    inCallNotification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            );
        }
        catch (Exception e) {
            Log.e(TAG, "answerCall() Failed to answer call", e);
            stopForegroundService();
        }
    }

    public void hangupCall() {
        CallInvite activeCallInvite = CallStateManager.getInstance().getActiveCallInvite();
        Call activeCall = CallStateManager.getInstance().getActiveCall();

        if (activeCall != null) {
            try {
                activeCall.disconnect();
            }
            catch (Exception e) {
                manualReset();
            }
        }
        else if (activeCallInvite != null) {
            try {
                activeCallInvite.reject(getApplicationContext());
            }
            catch (Exception ignored) { }

            manualReset();
        }
        else {
            manualReset();
        }
    }
    public void setSpeaker(boolean on) {
        audioSwitch.selectDevice(audioSwitch.getAvailableAudioDevices().stream()
                .filter(d -> d instanceof AudioDevice.Speakerphone == on)
                .findFirst().orElse(null)
        );

        CallStateManager.getInstance().setSpeaker(on);

        if (listener != null) {
            listener.onCallStateUpdated();
        }
    }

    public void setMute(boolean mute) {
        Call activeCall = CallStateManager.getInstance().getActiveCall();

        if (activeCall != null) {
            activeCall.mute(mute);
            CallStateManager.getInstance().setMute(mute);

            if (listener != null) {
                listener.onCallStateUpdated();
            }
        }
    }

    private final Call.Listener callListener = new Call.Listener() {
        @Override
        public void onConnected(@NonNull Call call) {
            CallStateManager.getInstance().setActiveCall(call);

            if (listener != null) {
                listener.onCallStateUpdated();
            }

            audioSwitch.activate();
        }

        @Override
        public void onDisconnected(@NonNull Call call, @Nullable CallException e) {
            CallStateManager.getInstance().updateCallState(CallStatus.DISCONNECTED, null, call.getFrom());

            if (listener != null) listener.onCallStateUpdated();

            // 3. Delay pentru animație
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
                if (CallStateManager.getInstance().getCallStatus() == CallStatus.DISCONNECTED) {
                    CallStateManager.getInstance().reset();
                }

                if (listener != null) listener.onCallStateUpdated();
                stopForegroundService();
            }, 1000);
        }

        @Override
        public void onConnectFailure(@NonNull Call call, @NonNull CallException e) {
            CallStateManager.getInstance().reset();

            if (listener != null) {
                listener.onCallStateUpdated();
            }

            stopForegroundService();
        }

        @Override
        public void onRinging(@NonNull Call call) {
            if (listener != null) {
                listener.onCallStateUpdated();
            }
        }

        @Override
        public void onReconnecting(@NonNull Call call, @NonNull CallException e) {
            if (listener != null) {
                listener.onCallStateUpdated();
            }
        }

        @Override
        public void onReconnected(@NonNull Call call) {
            if (listener != null) {
                listener.onCallStateUpdated();
            }
        }
    };

    private void manualReset() {
        CallStateManager.getInstance().reset();
//        NotificationHelper.getInstance(this).cancelCallNotification();
        stopForegroundService();
        if (listener != null) listener.onCallStateUpdated();
    }
}
